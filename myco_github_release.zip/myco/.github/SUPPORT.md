# Getting Support

## 💬 Fastest: Discord

Join the community Discord server for real-time help:

**[discord.gg/NTGWzPy4yB](https://discord.gg/NTGWzPy4yB)**

Post in `#help` and someone will usually respond within a few hours.

---

## 📖 Check the docs first

Your question may already be answered:

- **[FAQ](https://github.com/yourusername/myco/blob/main/docs/faq.md)** — the 30 most common questions
- **[Troubleshooting guide](https://github.com/yourusername/myco/blob/main/docs/troubleshooting.md)** — step-by-step fixes for known problems
- **[Full documentation](https://github.com/yourusername/myco/blob/main/docs/index.md)** — everything

---

## 🐛 Found a bug?

[Open a bug report](https://github.com/yourusername/myco/issues/new?template=bug_report.md) — include your OS, Python version, and the error message.

---

## 🔒 Security issue?

Do **not** open a public issue. See [SECURITY.md](https://github.com/yourusername/myco/blob/main/SECURITY.md) or DM a maintainer on Discord.
