---
name: Question / Help
about: Not sure how something works? Ask here — no question is too basic
title: "[QUESTION] "
labels: question
assignees: ''
---

## What do you want to know or do?

<!-- Describe what you are trying to figure out or accomplish. -->

## What have you tried so far?

<!-- Have you looked at the documentation? Tried something that didn't work? -->

## Your setup

**Operating system:** <!-- Windows / macOS / Linux -->
**Python version:** <!-- run: python3 --version -->
**Ollama installed:** <!-- Yes / No -->
**Using a cloud API:** <!-- Yes (which one?) / No -->

---

**Not sure if this is the right place?** It is. Ask away.

You can also ask on [Discord](https://discord.gg/NTGWzPy4yB) for faster responses.
