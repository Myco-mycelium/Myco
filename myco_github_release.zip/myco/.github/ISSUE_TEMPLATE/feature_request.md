---
name: Feature request
about: Suggest an idea or improvement
title: "[FEATURE] "
labels: enhancement
assignees: ''
---

## What would you like Myco to do?

<!-- Describe the feature you'd like. Be as specific as you can. -->

## Why would this be useful?

<!-- Who would benefit from this? How often would it be used? -->

## How might it work?

<!-- Any ideas about how it could be implemented? (You don't need to be technical — just describe the behaviour you'd like.) -->

## Alternatives you've considered

<!-- Are there other ways to achieve this? Is there a workaround? -->

## Would you be willing to help build this?

- [ ] Yes, I'd like to try implementing this
- [ ] Yes, I can help test it
- [ ] I can describe what I need but can't code it
- [ ] I just want to share the idea

---

**Not sure if it belongs here?** Open it anyway — there are no bad suggestions. The worst that happens is we discuss it and decide it doesn't fit right now.
