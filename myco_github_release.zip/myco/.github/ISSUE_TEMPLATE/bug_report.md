---
name: Bug report
about: Something is not working — tell us what happened
title: "[BUG] "
labels: bug
assignees: ''
---

## What happened?

<!-- Describe what went wrong. What were you doing? What did you see? -->

## What did you expect to happen?

<!-- What should have happened instead? -->

## Steps to reproduce

<!-- How can we make it happen again? Be as specific as possible. -->

1. 
2. 
3. 

## Error message

<!-- Copy-paste the full error message here. Don't screenshot — text is easier to search. -->

```
paste error message here
```

## Your setup

**Operating system:** <!-- e.g. Windows 11, Ubuntu 22.04, macOS 14 -->

**Python version:**
```bash
# Run this and paste the output:
python3 --version
```

**Myco version / commit:** <!-- e.g. v2.0.0 or the git commit hash -->

**AI model being used:** <!-- e.g. Ollama qwen2.5:1.5b, or "no model / offline mode" -->

## Logs

<!-- If you can, paste relevant lines from data/myco.log -->

```
paste log lines here
```

## Anything else?

<!-- Anything else that might help us understand the problem? -->

---

**Note:** If you found a security vulnerability, please do not open a public issue. See [SECURITY.md](../../SECURITY.md) instead.
