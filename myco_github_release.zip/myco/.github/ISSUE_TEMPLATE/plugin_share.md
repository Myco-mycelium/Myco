---
name: Share a Plugin
about: Built something useful? Share it with the community!
title: "[PLUGIN] "
labels: plugin, community
assignees: ''
---

## Plugin name

<!-- What is it called? -->

## What does it do?

<!-- Describe what the plugin adds to Myco. -->

## Type

- [ ] Tool — adds functions Myco can call during conversations
- [ ] Viewer — adds a visual panel to the UI
- [ ] Both

## The code

```python
# Paste your plugin code here
```

Or link to a GitHub file/repo:
<!-- https://github.com/... -->

## Example usage

<!-- Show an example of asking Myco to use it, or a screenshot of the viewer panel. -->

## Requirements

<!-- Does it need any packages installed? Does it need an API key? -->

## Notes

<!-- Anything else people should know? Known limitations? Ideas for improvement? -->

---

**Want faster feedback?** Share it on [Discord](https://discord.gg/NTGWzPy4yB) too — people there can test it and give you immediate thoughts.
