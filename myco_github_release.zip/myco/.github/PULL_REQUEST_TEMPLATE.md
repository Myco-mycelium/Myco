## What does this PR do?

<!-- Describe your changes in plain language. What did you add, fix, or improve? -->

## Why?

<!-- What problem does this solve? Link to an issue if there is one. -->
<!-- Closes #issue_number -->

## How did you test it?

<!-- What did you do to check your changes work? -->

- [ ] I ran `python -m pytest safety/tests/ -v` and all tests passed
- [ ] I started Myco and tested it manually
- [ ] I tested on: <!-- your OS and Python version -->

## Screenshots (if UI changes)

<!-- If you changed the UI, add before/after screenshots here -->

## Type of change

- [ ] Bug fix
- [ ] New feature
- [ ] Documentation improvement
- [ ] Performance improvement
- [ ] Security improvement
- [ ] Other: 

## Checklist

- [ ] My code follows the style of the existing code
- [ ] I have tested this works on my machine
- [ ] I have not committed `.env` or any API keys
- [ ] If I added a new file, it is in `.gitignore` if it should be ignored

---

**First time contributing?** Do not worry if you miss something on the checklist. We will figure it out together. 🌱
